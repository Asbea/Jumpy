const nome = document.getElementById("nome")
const email = document.getElementById("email")
const telefone = document.getElementById("tel")
const cpf = document.getElementById("cpf")
const senha = document.getElementById("senha")
const button = document.getElementById("button")
const alertaBotao = document.getElementById ("alertaBotao")

button.onclick = confereDados

function confereDados () {
    if(nome.value == "") {
        exibeAlerta (nome)
    } else {
        tiraAlerta (nome)
    }
    
    if(email.value == "") {
        exibeAlerta (email)
    } else {
        tiraAlerta (email)
    }

    if(tel.value == "") {
        exibeAlerta (tel)
    } else {
        tiraAlerta (tel)    
    }

    if(cpf.value == "") {
        exibeAlerta (cpf)
    } else {
        tiraAlerta (cpf)    
    }

    if(senha.value == "") {
        exibeAlerta (senha)
    } else {
        tiraAlerta (senha)
    }
}

function exibeAlerta (dado) {
    let nomes = dado.parentElement
    let alerta = nomes.querySelector ("p")
    alerta.innerHTML = "Campo Obrigatório"
    vazio ()

}

function tiraAlerta (dado) {
    let tira = dado.parentElement
    let alerta = tira.querySelector ("p")
    alerta.innerHTML = ""
    vazio ()

}

function vazio () {
    if(nome.value == "" || email.value == "" || tel.value == "" || cpf.value == "" || senha.value == "") {
        alertaBotao.innerHTML = "Campos obrigatórios não registrados."
    } else {
        alertaBotao.innerHTML = "Sucesso!"
        alertaBotao.classList = "verde"
    }
}
















